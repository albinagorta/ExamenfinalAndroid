<?php
    require "conexion.php";
    
    if($_SERVER['REQUEST_METHOD'] == 'GET') {
      // READ
      if(isset($_GET['codigo'])) {  
        // http://localhost/PruebasCanal/API_REST.php
        $codigo = $_GET['codigo'];

        $sql_select_id = "SELECT codigo, nombre, marca,precio,stock FROM tproducto WHERE codigo='$codigo'";

        $query_select_id = $mysqli->query($sql_select_id);
        
        $filas = $query_select_id->num_rows;
        if($filas == 0) {
          //echo "No existe ese registro";
          header("HTTP/1.0 204");
        } else {
          $resultado = $query_select_id->fetch_assoc();
          echo json_encode($resultado);
        }
      } else {
        
        $sql_select = "SELECT codigo, nombre, marca,precio,stock FROM tproducto";
        $query_select = $mysqli->query($sql_select);

        $datos = array();
        while($resultado = $query_select->fetch_assoc()) {
          $datos[] = $resultado;
        }

        echo json_encode($datos);
      }
    } else if($_SERVER['REQUEST_METHOD'] == 'POST') {
      // CREAD
      $datos = json_decode(file_get_contents("php://input"));
      $nombre = $datos->nombre;      
      $marca = $datos->marca;
      $precio = $datos->precio;
      $stock = $datos->stock;
      if(empty($nombre) || empty($stock) || empty($marca) || empty($precio)) {
        //echo "Faltan campos";
        header("HTTP/1.0 400");
      } else {
        $sql_insert = "INSERT INTO tproducto(nombre,marca,precio, stock) VALUES('$nombre', '$marca', '$precio','$stock')";

        $query_insert = $mysqli->query($sql_insert);

        echo "Se inserto correctamente";
      }
    } else if($_SERVER['REQUEST_METHOD'] == 'PUT') {
      // UPDATE
      $datos = json_decode(file_get_contents("php://input"));
      $codigo = $datos->codigo;
      $nombre = $datos->nombre;      
      $marca = $datos->marca;
      $precio = $datos->precio;
      $stock = $datos->stock;
      
      if(empty($codigo) || empty($nombre) || empty($stock) || empty($marca) || empty($precio)) {
        //echo "Faltan campos";
        header("HTTP/1.0 400");
      } else {
        $sql_update = "UPDATE tproducto SET nombre='$nombre' , marca='$marca' , precio='$precio', stock='$stock' WHERE codigo='$codigo' ";
        $query_update = $mysqli->query($sql_update);

        echo "Se actualizo correctamente";
      }
      
    } else if($_SERVER['REQUEST_METHOD'] == 'DELETE') {
      // DELETE
      if(isset($_GET['codigo'])) {
        $codigo = $_GET['codigo'];

        $sql_delete = "DELETE FROM tproducto WHERE codigo='$codigo'";
        $query_delete = $mysqli->query($sql_delete);

        echo "Se elimino el registro";
      } else {
        //echo "No hay elemento a borrar";
        header("HTTP/1.0 204");

      }
    }

?>